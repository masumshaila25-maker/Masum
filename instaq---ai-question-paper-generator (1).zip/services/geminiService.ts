
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { QuestionType, QuestionRequest, FilePart } from "../types";

const SYSTEM_INSTRUCTION = `
    তুমি একজন দক্ষ শিক্ষাবিদ এবং প্রশ্নপত্র প্রণয়নকারী। 
    প্রদত্ত প্রতিটি ফাইল (বইয়ের পাতা বা ডকুমেন্ট) নিখুঁতভাবে পড়ো এবং সব ফাইল থেকে পাওয়া তথ্যের সমন্বয় করো।
    নির্দেশনা: 
    ১. টেক্সট এর মাঝে কোনো প্রকার ** (ডাবল অ্যাস্টেরিস্ক) বা মার্কডাউন ফরম্যাটিং (যেমন #, *, _) ব্যবহার করবে না। 
    ২. টাইটেল বা হেডলাইনগুলো সাধারণ টেক্সট হিসেবে লিখবে।
    ৩. প্রতিটি প্রশ্নের ঠিক পরেই উত্তরটি স্পষ্টভাবে লিখে দাও।
    ৪. প্রতিটি প্রশ্নের নিচে অবশ্যই ঐ প্রশ্নের তথ্যের উৎস বা রেফারেন্স উল্লেখ করবে। রেফারেন্স হিসেবে ফাইলের নাম (বা পৃষ্ঠা নম্বর যদি টেক্সটে থাকে) এবং নির্দিষ্ট লাইন বা অনুচ্ছেদের বর্ণনা দিবে। 
       ফরম্যাট: [সূত্র: পৃষ্ঠা নং-XX, লাইন বা অনুচ্ছেদ-YY]
    ৫. বাংলা টেক্সটগুলো শুদ্ধ বানানে লিখবে।
    ৬. ইংরেজি টেক্সট থাকলে তা Times New Roman ফন্টে দেখার জন্য সাধারণ ইংরেজি অক্ষরে লিখবে।
`;

export const generateQuestionsFromImages = async (
  files: FilePart[],
  request: QuestionRequest
): Promise<string> => {
  // Use process.env.API_KEY directly as per GenAI initialization guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const typesDetails = Object.entries(request)
    .filter(([_, config]) => config.enabled)
    .map(([key, config]) => `${key}: ${config.count}টি`)
    .join(', ');

  const prompt = `
    ${SYSTEM_INSTRUCTION}
    
    অনুরোধকৃত প্রশ্নের তালিকা ও সংখ্যা:
    ${typesDetails}

    নির্দেশ: উপরের তালিকায় যে ধরণগুলোতে সংখ্যা দেওয়া আছে, ঠিক সেই সংখ্যক প্রশ্ন ও উত্তর তৈরি করো। প্রতিটি প্রশ্নের নিচে অবশ্যই সঠিক রেফারেন্স (পৃষ্ঠা ও লাইন) উল্লেখ করতে হবে। সব ফাইলের তথ্য ব্যবহার করো।
  `;

  const parts = files.map(file => ({
    inlineData: {
      mimeType: file.mimeType,
      data: file.data.split(',')[1] || file.data,
    },
  }));

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts: [...parts, { text: prompt }] },
    });

    let text = response.text || '';
    return cleanResponse(text);
  } catch (error) {
    console.error('Error generating questions:', error);
    throw new Error('AI থেকে রেসপন্স পেতে সমস্যা হয়েছে।');
  }
};

export const refineQuestions = async (
  currentContent: string,
  userInstruction: string
): Promise<string> => {
  // Use process.env.API_KEY directly as per GenAI initialization guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    ${SYSTEM_INSTRUCTION}

    বর্তমানে তৈরি করা প্রশ্নপত্র:
    """
    ${currentContent}
    """

    ব্যবহারকারীর নতুন নির্দেশনা: 
    "${userInstruction}"

    নির্দেশ: ব্যবহারকারীর নির্দেশনা অনুযায়ী উপরের প্রশ্নপত্রটি পরিবর্তন বা সংশোধন করে নতুন সম্পূর্ণ ভার্সনটি দাও। প্রতিটি প্রশ্নের সাথে রেফারেন্স (সূত্র) বজায় রাখতে হবে। কোনো মার্কডাউন ব্যবহার করবে না।
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    let text = response.text || '';
    return cleanResponse(text);
  } catch (error) {
    console.error('Error refining questions:', error);
    throw new Error('পরিবর্তন করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
  }
};

const cleanResponse = (text: string): string => {
  return text
    .replace(/\*\*/g, '') 
    .replace(/###/g, '')   
    .replace(/##/g, '')    
    .replace(/#/g, '')     
    .replace(/^- /gm, '')
    .trim();
};
